const {defineConfig} = require('@vue/cli-service')
module.exports = defineConfig({
    productionSourceMap:false,
    devServer: {
        proxy:{
            '/qf':{
                target:'http://localhost:8081/',
                // pathRewrite:{"^/qf":""},
                // ws:true,
                //
                changeOrigin:true
            }
        }

    },



    pages: {
        about: {
            title: 'about',
            entry: 'src/pages/about/main.js',
            template: 'public/about.html',
            filename: 'about.html'
        },
        index: {
            title: 'index',
            entry: 'src/pages/home/main.js',
            template: 'public/index.html',
            filename: 'index.html'
        },

        login: {
            title: 'login',
            entry: 'src/pages/login/main.js',
            template: 'public/login.html',
            filename:'login.html'
        },

    },
    publicPath:process.env.NODE_ENV === "development" ?"":"/qf/dist"


})
