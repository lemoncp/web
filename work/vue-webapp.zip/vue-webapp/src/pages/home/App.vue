<template>
  <div>
xxxxxxxxx
    <input v-model="user.name">
  </div>

</template>

<script>
export default {
  data(){
    return{
      user:{
        name:''
      }
    }
  },
  mounted() {}
};
</script>

<style lang="less">
</style>
