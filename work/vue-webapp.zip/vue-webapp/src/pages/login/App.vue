<template>
  <div>
  <Header></Header>
  <cont></cont>
    <LoMain class="loMain"></LoMain>

<login-foot class="logFoot"></login-foot>
  </div>
</template>

<script>
import Header from '@/components/component1/Header.vue'
import Cont from "@/components/component1/Cont.vue";
import LoMain from "@/components/component1/LoMain.vue";
import LoginFoot from "@/components/component1/LoginFoot.vue";
export default {

  components: {
    LoginFoot,
    Header,
    Cont,
    LoMain

  }
};
</script>

<style lang="css">

.loMain{
  position: relative;
  top: 15px;
}
.logFoot{
  position: relative;
  top: 16px;
}

</style>
