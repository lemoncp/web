<template>
<div :class="this.cla">{{this.info}}</div>
</template>

<script>
export default {
  name: "TextDiv2",

  props:{
    cla:{
      type:String,
      default:'default',
    },
    info:{
      type:String,
    }

  }
}
</script>

<style scoped>
div{
  font-family: "Helvetica Neue",Helvetica,"PingFang SC","Hiragino Sans GB","Microsoft YaHei","微软雅黑",Arial,sans-serif;
  font-weight: lighter;
}


.default{
  width:120px;
  height:35px;
  line-height:35px;
  font-size:12px;
}
.n2{
  width:200px;
  height:35px;
  line-height:35px;
  font-size: 12px;
}
.gang{
  width:12px;
  height:35px;
  line-height:35px;
  font-size: 15px;
  color: #d9d9d9;
}
.big{
  width:120px;
  height:49px;
  line-height: 49px;
  font-weight: 500;
  /*background-color: #e56415;*/
  text-align: center;
  /*font-family: 方正粗黑宋简体;*/
  font-size: 18px;
}
.small{
  display: block;
  margin:auto auto;
  font-size: 14px;

}
.gang2{
  width:10px;
  height:20px;
  line-height:20px;
  font-size: 15px;
  color: #b4b4b4;
  float: left;
}
</style>