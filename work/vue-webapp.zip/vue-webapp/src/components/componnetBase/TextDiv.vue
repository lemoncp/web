<template>
<div :style="{width:this.textW,height:this.textH,lineHeight:textH,fontSize:this.textSize}">{{this.info}}</div>
</template>

<script>
export default {
  name: "TextDiv",
  data(){
    return{

    }
  },
  props:{
    textH:{
      type:String,
      default:'35px'
    },
    textW:{
      type:String,
      default: '100px'
    },
    info:{
      type:String,
    },
    textSize:{
      type:String,
      default: '12px',
    }
  },

  computed:{
    d1(){
      return{
        "width":this.props.textH,
        "height":this.props.textW
      }
    }
  }
}
</script>

<style scoped>
div{
  font-family: "Helvetica Neue",Helvetica,"PingFang SC","Hiragino Sans GB","Microsoft YaHei","微软雅黑",Arial,sans-serif;
  font-weight: lighter;
}
</style>