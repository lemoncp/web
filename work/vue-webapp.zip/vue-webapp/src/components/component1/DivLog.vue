<template>
<div class="out">
<!--  表单-->
  <form class="out_form" method="post" action="/" @submit.prevent.once="simpleCheckCount()">
    <div class="form_div1">
      <div class="form_div1_one">
          <i :style="{backgroundImage:'url('+require('@/assets/imgs/phoneCode.svg')+')'}"></i>
          <input autocomplete v-show="changeP" v-model="user.Count" class="one_input" type="text"  placeholder="请输入账号"/>
          <input  v-show="!changeP" v-model="user.phoneCount" class="one_input" type="text"  placeholder="请输入手机号码"/>
      </div>

    </div>

    <p class="tip1">{{tip1}}</p>
<!--    -->
    <div class="form_div1 form_div2">
      <div class="form_div1_one">
        <i v-show="changeP" :style="{backgroundImage:'url('+require('@/assets/imgs/inputCode.svg')+')'}"></i>
        <i v-show="!changeP" :style="{backgroundImage:'url('+require('@/assets/imgs/yanzCode.svg')+')'}"></i>
        <input autocomplete v-model="user.CountPassowrd" v-show="changeP" class="one_input" type="password"  placeholder="请输入密码"/>
        <input v-model="user.authCode" v-show="!changeP" class="one_input_two" type="text"  placeholder="请输入验证码"/>
        <button type="button" :class="changeP ? 'one_button_none' : 'one_button'">获取验证码</button>
      </div>
    </div>
    <p class="tip1 tip2">{{tip2}}</p>


<!--    -->
    <div class="form_div1 form_div3">
      <div class="form_div1_one form_div1_one_nobord">
          <button v-show="changeP" class="sub" type="submit"  >登陆</button>
          <button v-show="!changeP" class="sub" type="submit">登陆</button>
      </div>
    </div>

    <p class="forget">
        <a href="/">忘记密码?</a>
    </p>




  </form>


</div>
</template>

<script>
export default {
  name: "DivLog",

  data(){
    return{
      //表单数据
      user:{
        //账号 密码
        Count:'',
        CountPassowrd:'',

        // 手机账号 验证码
        phoneCount:'',
        authCode:'',

      },


      //提示信息
      tip1:'',
      tip2:'',

      inputCode:require('@/assets/imgs/inputCode.svg'),
      yanzCode:require('@/assets/imgs/yanzCode.svg')

    }
  },

  methods:{

    //提示还原
    resetTIP1(){
      setTimeout( ()=>{

        this.tip1 = ''
        // console.log('gaibian',this.tip1)
      },2000)
    },

    //简单检测账号密码
    simpleCheckCount(){

      //输入为空
      if( this.user.Count == ''){
        this.tip1 = '您输入的内容为空'
        // console.log('xxxxxxxxxx')

        this.resetTIP1()
        // console.log('a')
        return
      }else {
        //输入不为空
        //发送请求查询数据
        //成功查到 。。。。跳转
          //如果查询用户名成功但密码失败返回tip2

        //查询失败 。。。。返回tips
        this.tip1='用户名不存在'
        this.resetTIP1();
        return;
      }
    }
  },

  props:{
    changeP:{
      type:Boolean,
      default:true
    }
  }
}
</script>

<style scoped>


.form_div3{
  position: relative;
  top: 1px;
}


.tip2{
  position: relative;
  top: -6px;
}
.tip1{

  display: inline-block;
  text-align: center;
  height: 16px;
  width: 268px;
  margin-top: 0px;
  margin-bottom: 0px;
  margin-left: 50px;
  font-weight: lighter;
  font-size: 10px;
  color: #ef0000;

}

.iopen{
  display: none;
}

.one_input_two{
  font-size: 12px;
  border: 0;
  padding: 0;
  outline: none;
  width: 186px;  /* -90 */
  height: 25px;
  position: relative;
  left: 12px;
}
.form_div2{
  position: relative;
  top: -6px;

}
/*
*/
.one_button_none{
  display: none;
}
.one_button{
  float: right;
  height: 34px;
  width: 90px;
  border: 0;
  font-size: 10px;
  font-weight: lighter;
  /*background-color: #e9ecf0;*/

}
.form_div1_one .one_input{
  font-size: 12px;
  border: 0;
  padding: 0;
  outline: none;
  width: 268px;
  height: 25px;
  position: relative;
  left: 12px;
}
.form_div1_one i{
  position: relative;
  top: 6px;
  left: 7px;
  display: inline-block;
  width: 21px;
  height: 21px;
  background-size: 21px 21px;
}

.form_div1_one{
  margin: 0 auto;
  width: 312px;
  height: 34px;
  border-radius: 2px;
  border: 1px solid #eaedf1;
  /*background-color: #d9d9d9;*/
}

.form_div1{

  margin-top: 10px;
  height: 36px;
  width: 360px;
  /*background-color: #ee9171;*/
}


.out_form{
  height: 240px;
}

.out{
  width: 360px;
  height: 240px;
  /*background-color: #c7bdba;*/
}

.form_div1_one_nobord{
  align-items: center;
  align-content: center;
  text-align: center;
  border: 1px;
}
.sub{
  display: inline-block;
  height: 36px;
  width: 312px;
  border: 0px;
  padding: 0px;
  border-radius: 24px;
  background-color: #ff734c;
  color: white;
  font-size: 18px;
}
.forget{
  display: block;
  margin: 10px auto;
  height: 25px;
  width: 312px;
  /*background-color: #ef0000;*/
  font-size: 12px;
  text-align: center;
  font-weight: lighter;

}
.forget a{
  text-decoration: none;
  color: black;
}


</style>