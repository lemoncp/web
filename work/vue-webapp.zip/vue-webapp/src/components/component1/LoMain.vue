<template>
  <div>
    <div class="main" :style="{backgroundImage:'url('+require('@/assets/imgpng/back.png')+')'}">
      <div class="main_login">
        <div class="main_login_top">
          <div class="main_login_top_left">
            <TextDiv2 :class="{'left_count': check }" info="用户登陆" cla="big" @click.native="check=true"></TextDiv2>
          </div>
          <div class="main_login_top_right">
            <TextDiv2 :class="{'left_count': !check }" info="用户注册" cla="big" @click.native="check=false"></TextDiv2>
          </div>

        </div>

        <div class="main_login_center" v-show="check">
<!--          切换组件-->
          <p @click="changeInfom();changep()">
            <i class="A_code" :style="{backgroundImage:'url('+require('@/assets/imgs/Acode.svg')+')'}"/>
            {{infom}}
          </p>
          <div-log class="center_main" :change-p=changeP ></div-log>

        </div>

      </div>

    </div>

  </div>
</template>

<script>
import TextDiv2 from "@/components/componnetBase/TextDiv2.vue";
import getQueryVariable from "@/myutil/getURLPara";
import DivLog from "@/components/component1/DivLog.vue";

export default {
  name: "LoMain",
  data() {
    return {
      check: false,
      infom:'手机验证码登陆',
      changeP:true,


    }
  },
  mounted() {
    // console.log('m',this.check)
    this.getCheck();
  },
  methods: {

    getCheck(){
    let che=getQueryVariable('check')
    console.log('check',che)
    if(che == null){
      this.check=true
    } else {

      if (che == 'false'){
        this.check=false
      }else if(che == 'true'){
        this.check=true
      }

    }
  },

    changeInfom(){
      if(this.infom === '手机验证码登陆'){
        this.infom = '账户密码登陆'
      }else if( this.infom === '账户密码登陆'){
        this.infom = '手机验证码登陆'
      }
    },

    changep(){
      this.changeP = !this.changeP},





  },
  components: {
    DivLog,
    TextDiv2},
}
</script>

<style scoped>
.center_main{
  position: relative;
  top:0px;
}

.A_code{
  position: relative;
  top: 3px;
  display: inline-block;
  height: 16px;
  width: 16px;
  background-size: 16px 16px;

  /*background-color: #e56415;*/

}
.main_login_center p{

  text-align: right;
  font-weight: lighter;
  font-size: 12px;
  color: #606060;
  display: inline-block;
  height: 24px;
  width: 336px;
  /*background-color: rgba(217, 217, 217, 0.36);*/
  padding-right: 15px;
  margin: 0;

}

.main_login_center{
  width: 360px;
  height: 280px;
  /*background-color: #e56415;*/
}



.main_login_top_left {

  width: 120px;
  height: 49px;
  border-bottom: 2px white solid;
  /*background-color: #e56415;*/
  position: relative;
  /*top: -10px;*/
  left: 32px;

}

.left_count {
  border-bottom: 2px #ff734c solid;
  color: #ff734c;
}


.main_login_top_right {
  width: 120px;
  height: 51px;

  /*background-color: #e1a47f;*/
  position: relative;
  top: -51px;
  left: 204px;

}

.main_login_top {
  width: 360px;
  height: 51px;
  /*background-color: rebeccapurple;*/
  border-bottom: 1px #ecebeb solid;
}

.main_login {
  width: 360px;
  height: 408px;
  background-color: white;
  position: relative;
  left: 960px;
  top: 20px;
  border-radius: 8px;
}

.main {
  width: 100%;
  height: 470px;
  /*background-color: #e56415;*/
  background-repeat: no-repeat;
  background-size: 100%;
}

</style>