<template>
<div class="out">
  <div class="di d1">
    <a href="/"><text-div2 cla="small" info="首页"></text-div2></a>

      <text-div2 cla="gang2" info="|"></text-div2>

    <a href="/"> <text-div2 cla="small" info="关于我们"></text-div2></a>

      <text-div2 cla="gang2" info="|"></text-div2>

    <a> <text-div2 cla="small" info="关于我们"></text-div2></a>
      <text-div2 cla="gang2" info="|"></text-div2>
    <a><text-div2 cla="small" info="友情连接"></text-div2></a>
       <text-div2 cla="gang2" info="|"></text-div2>
    <a><text-div2 cla="small" info="关于我们"></text-div2></a>

  </div>
  <div class="di d2">
    <img :src="require('@/assets/imgpng/loge2.jpeg')" />
    <img :src="require('@/assets/imgpng/xiaofeizhexiehui.jpeg')" />
    <img :src="require('@/assets/imgpng/shuangshengzi.jpg')" />

  </div>
  <div class="di d3" >
    <text-div2 cla="small" info="中国花卉协会    中国电子商务协会    经营许可证     网络备案号6970808-8号 Copyright @ 2023-21 "></text-div2>
  </div>
</div>
</template>

<script>

import TextDiv2 from "@/components/componnetBase/TextDiv2.vue";

export default {
  name: "LoginFoot",
  components: {
    TextDiv2
  }
}
</script>

<style scoped>
.out{
  border:1px #ffffff solid;
  width: 100%;
  height: 165px;
  /*background-color: #d5c7c7;*/
  text-align: center;
  padding-bottom: 10px;
}
.di{
  margin: 1px auto;
  border: 1px #ffffff solid;
  width: 100px;
  height: 30px;
  /*background-color: #d9d9d9;*/
}
.d1{
  width: 850px;
  margin-top: 10px;
}
.d1 a{
  /*border-left: 1px black solid;*/
  /*border-right: 1px black solid;*/
  /*border:1px solid black;*/

  display: inline-block;
  width: 150px;
  height: 30px;
  /*background-color: rebeccapurple;*/
  text-align: center;
  text-decoration: none;
  float: left;
}

a:hover{
  color: #e56415;
}

.d2{
  height: 70px;
  width: 600px;
}
.d2 img{
  height: 70px;
  width: 160px;
}
.d3{
  margin-top: 20px;
  width: 900px;
}


</style>