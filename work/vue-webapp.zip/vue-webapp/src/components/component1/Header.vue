<template>

  <el-col :span="24" style="margin-top: -8px;">
    <div class="grid-content bg-purple-dark">
<!--      收藏网站-->
      <header-div info="收藏网站" :res="require('@/assets/imgs/souchang.svg')" class="head-div head-div1" @click.native="collectWeb()"></header-div>
<!--      关注微信-->
      <header-div info="关注微信" :res="require('@/assets/imgs/wechat.svg')" class="head-div head-div2" @mouseenter.native="weiopen='block'" @mouseleave.native="weiopen='none'"></header-div>
      <div class="head-div-wei" :style="{display:weiopen}" >
        <img class="weix" :src="require('@/assets/imgs/wei.png')" />
      </div>

<!--中国礼品鲜花店-->
      <text-div2 class="head-div-r head-div-r1" info="中国鲜花礼品店"></text-div2>
      <text-div2 class="head-div-r" cla="gang" info="|"></text-div2>

<!--      购物车-->
      <div class="head-div-r head-div-car">
      <header-div  info="购物车" :res="require('@/assets/imgs/shopingcar.svg')" a-cla="acla2" style="width: 66px"></header-div>
        <i class="el-icon-caret-bottom mycss" ></i>
      </div>

      <text-div2 class="head-div-r" cla="gang" info="|"></text-div2>

<!--      客户服务-->
      <div class="head-div-r head-div-car">
        <text-div2  info="客户服务" style="display: inline;"></text-div2>
        <i class="el-icon-caret-bottom mycss" ></i>
      </div>

      <text-div2 class="head-div-r" cla="gang" info="|"></text-div2>

<!--      我的礼花-->
      <div class="head-div-r head-div-car" style="margin-right: 5px">
        <text-div2  info="我的礼花" style="display: inline;"></text-div2>
      </div>
      <text-div2 class="head-div-r" cla="gang" info="|"></text-div2>
<!--订单查询-->
      <div class="head-div-r head-div-car" style="margin-right: 5px">
        <text-div2  info="订单查询" style="display: inline;"></text-div2>
      </div>
      <text-div2 class="head-div-r" cla="gang" info="|"></text-div2>
<!--注册-->
      <div class="head-div-r head-div-car" style="margin-right: 5px" @click="toRegister()">
        <text-div2  info="注册" style="display: inline;"></text-div2>
      </div>
<!--登陆-->
      <div class="head-div-r head-div-car" style="margin-right: 5px" @click="toLogin()">
        <text-div2  info="您好,请登陆" style="display: inline;"></text-div2>
      </div>







    </div>
  </el-col>

</template>
<script>

import HeaderDiv from './HeaderDiv.vue'
import TextDiv2 from "@/components/componnetBase/TextDiv2.vue";

export default {
  name: "Header",
  data(){
    return{

      weiopen:"none",






    }
  },


  methods:{
    collectWeb(){
      let url=window.document.location.href;
      let title='花店'
      try {
        window.external.addFavorite(url, title);
        alert("收藏成功")
      }
      catch (e) {
        try {
          window.sidebar.addPanel(title, url, "我的收藏");

        }
        catch (e) {
          alert("抱歉，您所使用的浏览器无法完成此操作。\n\n加入收藏失败，请使用Ctrl+D进行添加");
        }
      }
    },


    // 只访问后端的tologin 剩下的由后端处理跳转
    toRegister(){
      document.location.href='http://localhost:8080/login.html?check=false'

    },

    toLogin(){
        //发送axios请求

        //允许登陆 返回网址
        document.location.href='http://localhost:8080/login.html?check=true'

     // this.axios({
     //   method:'post',
     //   url:'/qf/login',
     //   data:{
     //     username:this.$cookies.get('username'),
     //     pwd:this.$cookies.get('password'),
     //   }
     // }).then((resp)=>{//eslint-disable-line no-unused-vars
     //
     //   console.log('a')
     // })


    }






  },



  components:{
    HeaderDiv,
    TextDiv2
  }
}
</script>

<style scoped>

.mycss{
  /*float: right;*/
 color: #d9d9d9;
}
.head-div-car:hover{
  color: #ee9171;

}
.head-div-car:hover .mycss{
  color: #ee9171;
}

.head-div-r1{
  margin-right: 140px;
}

.head-div-r{
  float: right;
}

.head-div{

  float: left;
}
.head-div-car:hover .head-div{
  color: #ee9171;
}
.head-div1{
  margin-left: 160px;
}
.head-div1:hover {
  color: #ee9171;
}
.head-div2:hover{
  color: #ee9171;
}
.head-div2{
  margin-left: 10px;
}

.head-div-wei{

  position: absolute;
  top:45px;
  left:250px;
  z-index: 10;

}
.head-div-wei img{
  height: 180px;
  width: 180px;
}

.bg-purple-dark {
  background: #f2f2f2;
}

.grid-content {
  border-radius: 0px;
  min-height: 35px;
  border: #e6e6e6 1px solid;

}


</style>