<template>
<a :class=this.aCla>
<!--  <span :style="{backgroundImage: log}">{{log}}</span>-->
<!--  <span class="span1" v-bind:style="{backgroundImage:'url(' + this.res+ ')'}" ></span>-->
  <span :class=this.spanCla :style="{backgroundImage:'url('+this.res+')'}" ></span>
  {{this.info}}
<!--  <span class="span1" style="background-image: url('@/imgs/souchang.svg')" ></span>-->
<!--  <span class="span1"  ></span>-->

</a>
</template>

<script>

export default {
  name: "HeaderDiv",

  data(){
    return{

    }
  },
  props: {
    info:{
      type:String,

    },
    res:{
      type:String,

    },
    spanCla:{
      type:String,
      default:"iconspan1"
    },
    aCla:{
      type:String,
      default: "acla1"
    }

  },


}
</script>

<style scoped lang="css">
a{
  font-family: "Helvetica Neue",Helvetica,"PingFang SC","Hiragino Sans GB","Microsoft YaHei","微软雅黑",Arial,sans-serif;
  font-weight: lighter;
}
.iconspan1{
  /*//@vres: '';*/
  display: inline-block;
  width: 20px;
  height: 20px;
  /*background-color: rebeccapurple;*/
  position: relative;
  top: 4px;
  background-size: 20px 20px;



}
.acla1{

  min-height: 35px;
  min-width: 88px;
  max-width: 100px;
  display: block;
  /*background-color: aqua;*/
  line-height: 35px;
  font-size: 14px;
  /*background-color: rebeccapurple;*/

}
.acla2{
  width:120px;
  height:35px;
  line-height:35px;
  font-size:12px;
  /*background-color: rebeccapurple;*/
}

</style>