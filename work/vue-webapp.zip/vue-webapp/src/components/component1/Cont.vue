<template>
  <div class="div1">

    <div class="div1_l">

    <h1>
      <a>
        <img :src="require('@/assets/imgpng/weblogo.png')">
      </a>
    </h1>
    </div>


    <div class="div1_r">
      <form class="div1_r_from" action="" method="get">
        <div class="input_group">
            <input class="from_in" placeholder="请输入内容"/>
          <span>

            <button type="submit" class="from_bu">搜索</button>
          </span>
        </div>
      </form>
    </div>
  </div>
</template>

<script>
export default {
  name: "Cont",


  data() {
    return {
      input:'',

    }
  },

  methods: {
    // havepic(){
    //   this.axios({
    //     method:'get',
    //     url:'/qf/pic'
    //   }).then((resp)=>{
    //     console.log(resp.data)
    //     this.src=resp.data
    //   })
    //
    // }
  }
}
</script>

<style scoped>
span button{

  border: 0;
  padding: 0;
  height: 40px;
  width: 80px;
  background-color: #e56415;
  font-size: 20px;
  font-weight: normal;
  color: white;
  font-family: "Helvetica Neue",Helvetica,"PingFang SC","Hiragino Sans GB","Microsoft YaHei","微软雅黑",Arial,sans-serif;
  display: inline-block;
}
.input_group span{
  float: right;
  display: inline-block;
  /*background-color: #854c2b;*/
  height: 40px;
  width: 80px;
}
.from_in{

  outline: none;
  border: none;
  padding: 0px;
  margin-left: 10px;
  width: 220px;
  height: 40px;
  /*border: 1px solid red;*/
  font-size: 15px;

  font-family: "Helvetica Neue",Helvetica,"PingFang SC","Hiragino Sans GB","Microsoft YaHei","微软雅黑",Arial,sans-serif;
  /*background-color: rebeccapurple;*/

}
.input_group{
 /*background-color: rebeccapurple;*/
  width: 330px;
  height: 40px;

}
.div1_r_from{
  width: 330px;
  height: 40px;
  border-radius: 2px;
  border: 2px solid #e56415;

  /*background-color: red;*/
}
.div1_r{
  border-top:30px solid white;
  width: 520px;
  height: 80px;
  position: relative;
  left: 600px;
  top: -110px;
  /*background-color: rebeccapurple;*/
}

.div1 {
  /*margin-top:37px;*/
  position: relative;
  top: 28px;
  width: 100%;
  height: 120px;
  /*background-color: #ee9171;*/

}
.div1_l{
  position: relative;
  left: 160px;
  /*background-color: rebeccapurple;*/
  width: 500px;
  height: 120px;
}

h1 {
  margin: 0;
  position: relative;
  top: -29px;
  display: inline-block;
  width: 500px;
  height: 120px;
  /*background-color: #333333;*/
}
h1 a{
  display: inline-block;
  width: 500px;
  height:120px;
  /*background-color: #000;;*/
}
img{
  height: 120px;
  width: 300px;
}



</style>